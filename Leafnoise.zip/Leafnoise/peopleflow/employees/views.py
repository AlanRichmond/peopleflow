from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.pagination import PageNumberPagination
from .models import Employee
from .serializers import EmployeeSerializer
from mongoengine.errors import DoesNotExist

# Paginación personalizada
class EmployeePagination(PageNumberPagination):
    page_size = 10  # cantidad por defecto
    page_size_query_param = 'page_size'  # permite modificar page_size desde la URL.
    max_page_size = 100  # maximo permitido por request

class EmployeeListCreateAPIView(APIView):
    def get(self, request):
        # Filtrar por puesto si se indica
        puesto = request.GET.get('puesto')
        employees = Employee.objects(puesto=puesto) if puesto else Employee.objects()

        # Aplicar paginación
        paginator = EmployeePagination()
        result_page = paginator.paginate_queryset(employees, request)
        serializer = EmployeeSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)

    def post(self, request):
        serializer = EmployeeSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class EmployeeDetailAPIView(APIView):
    def get_object(self, id):
        try:
            return Employee.objects.get(id=id)
        except DoesNotExist:
            return None

    def get(self, request, id):
        employee = self.get_object(id)
        if not employee:
            return Response({"error": "Empleado no encontrado"}, status=status.HTTP_404_NOT_FOUND)
        serializer = EmployeeSerializer(employee)
        return Response(serializer.data)

    def put(self, request, id):
        employee = self.get_object(id)
        if not employee:
            return Response({"error": "Empleado no encontrado"}, status=status.HTTP_404_NOT_FOUND)
        serializer = EmployeeSerializer(employee, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, id):
        employee = self.get_object(id)
        if not employee:
            return Response({"error": "Empleado no encontrado"}, status=status.HTTP_404_NOT_FOUND)
        employee.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
