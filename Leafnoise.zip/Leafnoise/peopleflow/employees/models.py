from mongoengine import Document, StringField, EmailField, DecimalField, DateField, UUIDField
import uuid

class Employee(Document):
    id = UUIDField(primary_key=True, default=uuid.uuid4)
    nombre = StringField(max_length=100, required=True)
    apellido = StringField(max_length=100, required=True)
    email = EmailField(required=True, unique=True)
    puesto = StringField(max_length=100, required=True)
    salario = DecimalField(required=True, precision=2)
    fecha_ingreso = DateField(required=True)

    meta = {'collection': 'employees'}

    def __str__(self):
        return f"{self.nombre} {self.apellido} <{self.email}>"
