from rest_framework import serializers
from .models import Employee

class EmployeeSerializer(serializers.Serializer):
    id = serializers.UUIDField(read_only=True)
    nombre = serializers.CharField(max_length=100)
    apellido = serializers.CharField(max_length=100)
    email = serializers.EmailField()
    puesto = serializers.CharField(max_length=100)
    salario = serializers.DecimalField(max_digits=10, decimal_places=2)
    fecha_ingreso = serializers.DateField()

    def create(self, validated_data):
        from .models import Employee
        return Employee(**validated_data).save()

    def update(self, instance, validated_data):
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance
